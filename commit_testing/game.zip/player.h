#include <string>
using namespace std;

class Player {
	private:
		string playerName;
	public:
		string getName();
		void setName();
};
