#include "game.h"
#include "player.h"

void Game::Play() {
	Player P1;
	P1.setName();
}
