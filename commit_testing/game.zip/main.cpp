#include <string>
#include <iostream>
#include <fstream>
#include "game.h"

using namespace std;

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main(int argc, char** argv) {
	Game Game_obj;
	Game_obj.Play();
	return 0;
}
