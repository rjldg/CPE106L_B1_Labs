

class Game {
	public:
		void Play();
};
